# CurveDrive v2.5 test results

実施日: 2026-11-15 (Asia/Tokyo)

## 結果

| 検査 | 結果 | 条件 |
| --- | --- | --- |
| C#コンパイル | 成功、警告0 | Mono 6.12、C#5、System.Web.Extensions参照、警告をエラー扱い |
| HTML/JS・入力・復元・送信 | 51/51合格 | Node.js 24、元HTMLのスクリプトをVM上で検査 |
| C# HTTP/状態/出力/競合 | 19/19合格 | 実際のBridge.exeをMonoで実行、隔離した一時フォルダ |
| BAT/CMD静的検査 | 9/9合格 | CRLF/ASCII/BOM・ディレクティブ・出力・引用符・起動順序 |
| ブラウザ結合試験 | 11/11チェック合格 | Chromium156 + 実際のBridge.exe/Mono、JWC_TEMPのみ模擬 |

合計90件/チェック合格。CAD自体の作図成功を示す数字ではない。
各実行ログはtestsのFrontend.log、Bridge.log、Batch.log、Browser.logに保存。

## 再実行例（開発者用）

Windows現場でNode/Python/Monoを導入する必要はない。通常起動はOpen.cmdのみ。
以下は今回のLinux開発環境での検査手順。

```sh
/workspace/work/toolchain/mcs.sh -nologo -langversion:5 -warnaserror -target:exe -r:System.Web.Extensions -out:Bridge.exe Bridge.cs
node --test tests/frontend.cjs
python3 tests/bridge.py --exe Bridge.exe --mono /workspace/work/toolchain/mono.sh -v
python3 tests/batch.py
node tests/browser.cjs
```

MonoのローカルラッパーはこのZIPに含めない。別環境では対応するMono実行パスを指定する。
ブラウザ試験はPlaywrightが必要。CURVE_MONO_PATH、CURVE_CHROMIUM_PATHで実行パスを指定できる。
固定ポート18718を使う試験は直列実行し、既にサーバーがいる場合は試験を中止する。
WindowsのPython環境ではbridge.pyの--mono指定を省略できるが、今回はWindowsで未実施。

## 主な確認内容

- 不正JSON/CSVや壊れた自動保存を読んでも有効な現在値を失わない。
- 直線、左右R100円弧、10.5m、非ゼロ発進座標、DXFの色・測点座標。
- 連携の基準終点登録、現場/計画/セッション/前点の不一致拒否。
- 同一pending再送の冪等性、次の測点による未引渡しデータ上書き拒否。
- 同じ点の再引渡し、競合する同時引渡しを防ぐ。
- 受信後/引渡し後の再起動で状態を維持。壊れた状態を上書きしてやり直さない。
- 古い測点行・修飾キー・変換中・長押しで無関係な測点を送らない。
- タイムアウト/応答喪失と確定した拒否を区別。
- 実ブラウザでDXFダウンロード→終点登録→Enter11m→pending→模擬外部変形issued→再実行拒否。
- 続けて11.5m送信、画面再読込後も測点と状態保持。不正ファイル入力後も保持。

## Windows/JW_CADで残る試験

Readme.txtの直線サンプル手順に従って、テスト用コピーだけで照合する。

1. Open.cmd→Windows上での.NET FrameworkコンパイルとEdge起動。
2. Windows HttpListenerの起動、localhost通信、実機のブラウザ許可。
3. 現場で使用するJW_CADのバージョンと、正しいCurve_Latest.batを選択したこと。
4. 発進点(0m)の指定、CADの軸角・グループ縮尺・単位とDXF座標の照合。
5. 計画線が残り、指定した実測点と前点からの線のみ追加されること。
6. 左20mm/右20mm、10.5m/40mのCAD上の実寸偏差と座標。
7. 同一BAT再実行がheエラーで止まり、同じ実測図形が増えないこと。
8. CAD取込取消し/失敗/中断では、引渡し済みと描画成功が区別されること。
9. 旧版の終了、別図面/別フォルダ/Undo/過去点訂正を含む実運用フロー。

図形数・計画線保護・座標精度はJW_CAD実機上では未確認。
