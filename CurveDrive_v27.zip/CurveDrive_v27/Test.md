# v2.7 test results

C#5/.NET Framework互換コンパイル: Mono6.12、警告をエラー扱いで成功。

| 検査 | 結果 |
| --- | --- |
| Frontend / 元HTMLの構文・計算・復元・出力・送信 | 54/54合格 |
| Bridge / 実行EXEのHTTP・状態保存・排他・引渡し | 21/21合格 |
| BAT/CMDの静的検査 | 9/9合格 |
| 実ブラウザChromium + Monoサーバー結合試験 | 11/11チェック合格 |

合計95件/チェック合格。生ログは配布せず、この要約を同梱する。

## 今回の回帰検査

- 合成CADヘッダーで縮尺1/1、1/100、1/1000を指定しても、
  出力はb0の実寸mmを維持し、座標と半径を縮尺倍/縮尺割りしない。
- 例: 10.5m/+18mmの合成直線点を、X10500mm/Y18mm・半径35mmで出力。
- v2.6の保存状態は拒否し、再引渡ししない。
- v2.6から実測入力値のみを移行し、データを1000倍等に書き換えない。
- DXFの50m→50000mm、左右/上下20mm、平面/縦断/範囲/マークのmm換算。
- 10.5m/40mの曲線位置、非ゼロ発進座標、左右符号、CSV/JSONの保全。
- ブラウザでDXF出力→終点登録→Enter→実寸mm/b0引渡し→再実行拒否。

ヘッダー/出力を使った試験はJw_cadエンジンを実行する試験ではない。

## 開発者用の再実行例

```
node --test tests/frontend.cjs
python3 tests/bridge.py --exe Bridge.exe --mono /path/to/mono -v
python3 tests/batch.py
node tests/browser.cjs
```

ブラウザ試験はPlaywright、CURVE_MONO_PATH、CURVE_CHROMIUM_PATHの設定が必要。
Windowsでの通常操作にはNode/Python/Monoは不要。Open.cmdで起動する。
C#のビルドにはSystem.Web.Extensions参照が必要。
固定ポートを使う試験は直列実行し、試験ごとにコピーと一時フォルダを使う。

## 未実施

WindowsのCMD/Edge/.NET Framework実機、v2.7を使ったJW_CAD取込/位置/偏差量の照合。
新しいテスト図面で、実寸、追加点、左右偏差、原点を確認してから先に進む。
非ゼロ軸角・複数レイヤグループ・異なる縮尺での実機照合も未実施。
CAD取込成功通知、過去点だけの自動置換、EnterのみでのCAD操作は未実装。
