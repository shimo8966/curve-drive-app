# v2.6 test results

2026-11-15 (Asia/Tokyo)

C#5/.NET Framework互換コンパイル: Mono6.12、警告をエラー扱いで成功。

- Frontend: 53/53合格（構文、幾何、DXF、復元、旧版データ移行、送信制御）。
- Bridge: 19/19合格（実際のHTTP/永続化/排他/引渡し/再実行拒否）。
- Batch: 9/9合格（ASCII/CRLF/ディレクティブ/引用符/失敗時の出力等の静的検査）。
- Browser: Chromium156 + Monoの結合試験11チェック合格。

計92件/チェック合格。公開用ZIPには、開発環境の生ログを含めず、この要約のみ同梱する。
今回の新しい回帰検査では、直線50mのDXF終点50000mm、左右+20mmのY20mm、
マーク半径35mm、縦断の延長と上下+20mmの換算を確認。
外部変形も、10.5m/+18mmをX10500mm/Y18mmとし、bz、線、半径35mmの円を確認。
HTTP・保存データのm座標は変換せず、CAD出力境界で一回だけ変換する。
実際のブラウザでDXF出力→終点登録→Enter送信→模擬外部変形→再実行拒否まで確認。

## 再実行（開発者向け）

```
node --test tests/frontend.cjs
python3 tests/bridge.py --exe Bridge.exe --mono /path/to/mono -v
python3 tests/batch.py
node tests/browser.cjs
```

C#コンパイルにはSystem.Web.Extensions参照が必要。
MonoラッパーはZIPに含めない。browser試験はPlaywright/ChromiumとCURVE_MONO_PATH設定が必要。
通常の現場PC操作でNode/Python/Monoを導入する必要はない。Open.cmdがWindowsの.NETで再コンパイル。
固定ポートを使う試験は直列実行。試験はコピーを作り本番状態を変更しない。

## 未検証

Windows CMD/Edge/.NET Framework実機、およびJW_CADでのv2.6の取込・図形の位置・実寸。
写真で確認した50mmはv2.5の結果であり、v2.6のWindows実機成功はまだ確認していない。
bz方式は公式仕様に従うが、対象Jw_cadの軸角、グループ縮尺、原点指定との照合が必要。
まず新しく出したPlan_mm.dxfを新しいテスト図面として開き、50mを50000mmと測れることを確認。
その後、実測終点を登録して左右+20mm/-20mmを追加し、CAD実寸と位置を照合する。

## 公開用の確認

個人のアカウント名を含む固定URLをソースから除き、EXEを再ビルドした。
同梱データは架空の試験データ。実際の現場データ、ユーザーのバックアップ、
状態ファイル、実行履歴、画面写真、開発環境の生ログは含めていない。
連携はこのPC内の画面またはローカルHTMLから行う。
