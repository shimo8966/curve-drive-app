@echo off
setlocal EnableExtensions DisableDelayedExpansion
cd /d "%~dp0"
start "CurveDrive v2.6" "%ComSpec%" /d /c ""%~dp0Start.cmd""
exit /b 0
