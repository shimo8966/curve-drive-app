@echo off
setlocal EnableExtensions DisableDelayedExpansion
cd /d "%~dp0"
title CadCheck 1.1 - read only
if not exist "%~dp0Check.exe" goto missing
"%~dp0Check.exe"
pause
exit /b 0
:missing
echo Check.exe is missing. Extract ALL files from CadCheck11.zip first.
pause
exit /b 1
