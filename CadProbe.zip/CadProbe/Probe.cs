using System;
using System.IO;
using System.Text;
using System.Diagnostics;
using System.Collections.Generic;
using System.Runtime.InteropServices;
class Probe {
 delegate bool Callback(IntPtr h,IntPtr p);
 [DllImport("user32.dll")] static extern bool EnumWindows(Callback cb,IntPtr p);
 [DllImport("user32.dll")] static extern bool EnumChildWindows(IntPtr h,Callback cb,IntPtr p);
 [DllImport("user32.dll")] static extern uint GetWindowThreadProcessId(IntPtr h,out uint pid);
 [DllImport("user32.dll",CharSet=CharSet.Unicode)] static extern int GetWindowText(IntPtr h,StringBuilder s,int n);
 [DllImport("user32.dll",CharSet=CharSet.Unicode)] static extern int GetClassName(IntPtr h,StringBuilder s,int n);
 [DllImport("user32.dll")] static extern IntPtr GetMenu(IntPtr h);
 [DllImport("user32.dll")] static extern int GetMenuItemCount(IntPtr h);
 [DllImport("user32.dll")] static extern IntPtr GetSubMenu(IntPtr h,int i);
 [DllImport("user32.dll")] static extern uint GetMenuItemID(IntPtr h,int i);
 [DllImport("user32.dll",CharSet=CharSet.Unicode)] static extern int GetMenuString(IntPtr h,uint i,StringBuilder s,int n,uint f);
 [DllImport("user32.dll")] static extern int GetDlgCtrlID(IntPtr h);
 [DllImport("user32.dll")] static extern bool IsWindowVisible(IntPtr h);
 [DllImport("user32.dll")] static extern bool IsWindowEnabled(IntPtr h);
 static string Class(IntPtr h){var s=new StringBuilder(256);GetClassName(h,s,s.Capacity);return s.ToString();}
 static string Safe(string text){
  string lower=text.ToLowerInvariant();
  if(text.Contains("\\")||text.Contains(":")||lower.Contains(".dxf")||lower.Contains(".jww")||lower.Contains(".jwc"))return "[file/path omitted]";
  return text.Replace("\r"," ").Replace("\n"," ");
 }
 static string Info(IntPtr h,bool top){
  string c=Class(h),value="[value omitted]";
  if(!top&&(c=="Button"||c=="Static")){var s=new StringBuilder(256);GetWindowText(h,s,s.Capacity);value=Safe(s.ToString());}
  return "handle="+h.ToInt64().ToString("X")+" id="+GetDlgCtrlID(h)+" visible="+IsWindowVisible(h)+" enabled="+IsWindowEnabled(h)+" class="+c+" text="+value;
 }
 static int menuRows;
 static void Menu(StringBuilder output,IntPtr menu,int depth){
  if(menu==IntPtr.Zero||depth>8)return;
  for(int i=0;i<GetMenuItemCount(menu)&&menuRows<1500;i++){
   var s=new StringBuilder(256);GetMenuString(menu,(uint)i,s,s.Capacity,0x400);
   output.AppendLine(new string(' ',depth*2)+"MENU id="+GetMenuItemID(menu,i)+" text="+Safe(s.ToString()));
   menuRows++;Menu(output,GetSubMenu(menu,i),depth+1);
  }
 }
 static int Main(string[] args){
  if(args.Length==1&&args[0]=="--about"){Console.WriteLine("CadProbe 1.0: read-only Jw_win menus/controls. No input, commands, network or CAD modification.");return 0;}
  if(args.Length!=0)return 2;
  if(Environment.OSVersion.Platform!=PlatformID.Win32NT){Console.WriteLine("Run on Windows with Jw_cad.");return 2;}
  Console.OutputEncoding=Encoding.UTF8;
  Console.WriteLine("Jw_cadの「その他→外部変形」で、ファイル選択画面を開いてください。");
  Console.WriteLine("BATは選ばず、その画面を開いたまま、この黒い画面へ戻ってEnterを押してください。");
  Console.WriteLine("画面項目を読むだけです。CADへのキー入力・マウス操作・図面変更は行いません。");
  Console.ReadLine();
  var targets=new HashSet<uint>();
  foreach(var process in Process.GetProcesses()){
   try{if(String.Equals(process.ProcessName,"Jw_win",StringComparison.OrdinalIgnoreCase))targets.Add((uint)process.Id);}
   catch{}finally{process.Dispose();}
  }
  if(targets.Count==0){Console.WriteLine("Jw_cadが見つかりません。");return 1;}
  var report=new StringBuilder("CadProbe 1.0 / read-only private diagnostic\r\nFile paths, file names and editable values are omitted.\r\n");
  int windows=0;
  EnumWindows(delegate(IntPtr h,IntPtr unused){
   uint pid;GetWindowThreadProcessId(h,out pid);if(!targets.Contains(pid)||!IsWindowVisible(h))return true;
   windows++;report.AppendLine("WINDOW "+Info(h,true));Menu(report,GetMenu(h),0);
   int count=0;EnumChildWindows(h,delegate(IntPtr child,IntPtr ignored){
    if(++count>350)return false;uint childPid;GetWindowThreadProcessId(child,out childPid);
    if(targets.Contains(childPid))report.AppendLine(" CONTROL "+Info(child,false));return true;
   },IntPtr.Zero);return true;
  },IntPtr.Zero);
  try{File.WriteAllText(Path.Combine(AppDomain.CurrentDomain.BaseDirectory,"Probe.txt"),report.ToString(),new UTF8Encoding(false));}
  catch(Exception e){Console.WriteLine("保存できません: "+e.Message);return 1;}
  Console.WriteLine("読み取り完了。ウィンドウ数: "+windows+"。このフォルダーの Probe.txt をチャットに添付してください。");
  return windows>0?0:1;
 }
}
