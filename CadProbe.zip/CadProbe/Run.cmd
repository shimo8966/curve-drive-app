@echo off
setlocal EnableExtensions DisableDelayedExpansion
cd /d "%~dp0"
title CadProbe - read only
set "CSC=%SystemRoot%\Microsoft.NET\Framework64\v4.0.30319\csc.exe"
if not exist "%CSC%" set "CSC=%SystemRoot%\Microsoft.NET\Framework\v4.0.30319\csc.exe"
if not exist "%CSC%" goto failed
"%CSC%" /nologo /langversion:5 /target:exe /out:"%~dp0Probe.exe" "%~dp0Probe.cs"
if errorlevel 1 goto failed
"%~dp0Probe.exe"
pause
exit /b 0
:failed
echo Cannot compile. Keep the error message above.
pause
exit /b 1
