using System;
using System.Text;
using System.IO;
using System.Threading;
using System.Runtime.InteropServices;
using WinProcess=System.Diagnostics.Process;

// Full standard IAccessible vtable order (oleacc.idl). Dual calls avoid late-bound property invocation.
[ComImport,Guid("618736E0-3C3D-11CF-810C-00AA00389B71"),InterfaceType(ComInterfaceType.InterfaceIsDual)]
interface CadAccessible {
 [return:MarshalAs(UnmanagedType.IDispatch)] object Parent();
 int Count();
 [return:MarshalAs(UnmanagedType.IDispatch)] object Child([MarshalAs(UnmanagedType.Struct)]object child);
 [return:MarshalAs(UnmanagedType.BStr)] string Name([MarshalAs(UnmanagedType.Struct)]object child);
 [return:MarshalAs(UnmanagedType.BStr)] string Value([MarshalAs(UnmanagedType.Struct)]object child);
 [return:MarshalAs(UnmanagedType.BStr)] string Description([MarshalAs(UnmanagedType.Struct)]object child);
 [return:MarshalAs(UnmanagedType.Struct)] object Role([MarshalAs(UnmanagedType.Struct)]object child);
 [return:MarshalAs(UnmanagedType.Struct)] object State([MarshalAs(UnmanagedType.Struct)]object child);
 [return:MarshalAs(UnmanagedType.BStr)] string Help([MarshalAs(UnmanagedType.Struct)]object child);
 int HelpTopic([MarshalAs(UnmanagedType.BStr)]out string file,[MarshalAs(UnmanagedType.Struct)]object child);
 [return:MarshalAs(UnmanagedType.BStr)] string Shortcut([MarshalAs(UnmanagedType.Struct)]object child);
 [return:MarshalAs(UnmanagedType.Struct)] object Focus();
 [return:MarshalAs(UnmanagedType.Struct)] object Selection();
 [return:MarshalAs(UnmanagedType.BStr)] string DefaultAction([MarshalAs(UnmanagedType.Struct)]object child);
 void Select(int flags,[MarshalAs(UnmanagedType.Struct)]object child);
 void Location(out int left,out int top,out int width,out int height,[MarshalAs(UnmanagedType.Struct)]object child);
 [return:MarshalAs(UnmanagedType.Struct)] object Navigate(int direction,[MarshalAs(UnmanagedType.Struct)]object start);
 [return:MarshalAs(UnmanagedType.Struct)] object HitTest(int x,int y);
 void Invoke([MarshalAs(UnmanagedType.Struct)]object child);
 void SetName([MarshalAs(UnmanagedType.Struct)]object child,[MarshalAs(UnmanagedType.BStr)]string name);
 void SetValue([MarshalAs(UnmanagedType.Struct)]object child,[MarshalAs(UnmanagedType.BStr)]string value);
}
class CadWindow {public IntPtr handle;public int pid;public long started;}
class CadNative {
 delegate bool Callback(IntPtr h,IntPtr p);
 [DllImport("user32.dll")] static extern bool EnumWindows(Callback callback,IntPtr p);
 [DllImport("user32.dll")] static extern uint GetWindowThreadProcessId(IntPtr h,out uint pid);
 [DllImport("user32.dll")] static extern bool IsWindowVisible(IntPtr h);
 [DllImport("user32.dll")] static extern bool IsWindowEnabled(IntPtr h);
 [DllImport("user32.dll",CharSet=CharSet.Unicode)] static extern int GetWindowText(IntPtr h,StringBuilder s,int n);
 [DllImport("user32.dll")] static extern IntPtr GetMenu(IntPtr h);
 [DllImport("user32.dll")] static extern int GetMenuItemCount(IntPtr menu);
 [DllImport("user32.dll")] static extern IntPtr GetSubMenu(IntPtr menu,int index);
 [DllImport("user32.dll")] static extern uint GetMenuItemID(IntPtr menu,int index);
 [DllImport("user32.dll",CharSet=CharSet.Unicode)] static extern int GetMenuString(IntPtr menu,uint index,StringBuilder s,int n,uint flags);
 [DllImport("user32.dll",SetLastError=true)] static extern bool PostMessage(IntPtr h,uint message,IntPtr w,IntPtr l);
 [DllImport("user32.dll")] static extern IntPtr GetDlgItem(IntPtr h,int id);
 [DllImport("user32.dll")] static extern IntPtr GetAncestor(IntPtr h,uint flags);
 [DllImport("user32.dll")] static extern IntPtr GetForegroundWindow();
 [DllImport("user32.dll")] static extern bool SetForegroundWindow(IntPtr h);
 [DllImport("oleacc.dll")] static extern int AccessibleObjectFromWindow(IntPtr h,uint objectId,ref Guid iid,[MarshalAs(UnmanagedType.Interface)]out CadAccessible accessible);
 static string Title(IntPtr h){var s=new StringBuilder(1024);GetWindowText(h,s,s.Capacity);return s.ToString();}
 static uint External(IntPtr menu,int depth){
  if(menu==IntPtr.Zero||depth>8)return 0;
  for(int i=0;i<GetMenuItemCount(menu);i++){
   var s=new StringBuilder(200);GetMenuString(menu,(uint)i,s,s.Capacity,0x400);
   string label=s.ToString().Replace("(&G)","").Replace("&","").Trim();
   uint id=GetMenuItemID(menu,i);if(label=="外部変形"&&id!=0&&id!=UInt32.MaxValue)return id;
   uint nested=External(GetSubMenu(menu,i),depth+1);if(nested!=0)return nested;
  }return 0;
 }
 public static CadWindow Find(CadLink binding,bool busy){
  if(Environment.OSVersion.Platform!=PlatformID.Win32NT)throw new Fault(501,"AUTO_WINDOWS_ONLY");
  CadWindow found=null;int count=0;
  EnumWindows(delegate(IntPtr h,IntPtr ignored){
   if(!IsWindowVisible(h))return true;
   uint pid;GetWindowThreadProcessId(h,out pid);
   try{using(var p=WinProcess.GetProcessById((int)pid)){
    if(!String.Equals(p.ProcessName,"Jw_win",StringComparison.OrdinalIgnoreCase))return true;
    if(GetMenu(h)==IntPtr.Zero||External(GetMenu(h),0)==0)return true;
    count++;found=new CadWindow{handle=h,pid=p.Id,started=p.StartTime.ToUniversalTime().Ticks};
   }}catch{}return true;
  },IntPtr.Zero);
  if(count!=1||found==null)throw new Fault(409,"AUTO_REQUIRE_SINGLE_JWCAD");
  if(binding!=null){
   if(found.pid!=binding.pid||found.started!=binding.started)throw new Fault(409,"CAD_PROCESS_CHANGED");
   if(Title(found.handle).IndexOf(Path.GetFileName(binding.drawing),StringComparison.OrdinalIgnoreCase)<0)throw new Fault(409,"CAD_TITLE_CHANGED");
  }
  if(!busy&&!IsWindowEnabled(found.handle))throw new Fault(409,"CAD_DIALOG_OPEN");
  return found;
 }
 static IntPtr FileList(CadWindow main){
  IntPtr result=IntPtr.Zero;int count=0;
  EnumWindows(delegate(IntPtr h,IntPtr ignored){
   uint pid;GetWindowThreadProcessId(h,out pid);
   if(pid!=(uint)main.pid||!IsWindowVisible(h)||GetAncestor(h,3)!=main.handle)return true;
   IntPtr list=GetDlgItem(h,1882);if(list!=IntPtr.Zero&&IsWindowVisible(list)){result=list;count++;}return true;
  },IntPtr.Zero);
  return count==1?result:IntPtr.Zero;
 }
 static void Choose(IntPtr list,string filename){
  Guid iid=typeof(CadAccessible).GUID;CadAccessible accessible=null;
  try{
   if(AccessibleObjectFromWindow(list,unchecked((uint)-4),ref iid,out accessible)!=0||accessible==null)throw new Fault(409,"AUTO_LIST_NOT_ACCESSIBLE");
   int count=accessible.Count();if(count>2000)throw new Fault(409,"AUTO_LIST_TOO_LARGE");
   int match=0,hits=0;
   for(int i=1;i<=count;i++){
    string name="";try{name=accessible.Name(i);}catch{}
    if(String.Equals((name??"").Trim(),filename,StringComparison.OrdinalIgnoreCase)||String.Equals((name??"").Trim(),Path.GetFileNameWithoutExtension(filename),StringComparison.OrdinalIgnoreCase)){match=i;hits++;}
   }
   if(hits!=1)throw new Fault(409,"AUTO_MACRO_NOT_IN_CURRENT_FOLDER");
   accessible.Select(2,match);accessible.Invoke(match);
  }finally{if(accessible!=null&&Marshal.IsComObject(accessible))Marshal.ReleaseComObject(accessible);}
 }
 public static void Execute(CadLink link,Func<bool> completed){
  CadWindow main=Find(link,false);IntPtr previous=GetForegroundWindow();
  uint command=External(GetMenu(main.handle),0);
  if(command==0||!PostMessage(main.handle,0x111,new IntPtr((long)command),IntPtr.Zero))throw new Fault(409,"AUTO_MENU_FAILED");
  try{
   IntPtr list=IntPtr.Zero;DateTime until=DateTime.UtcNow.AddSeconds(5);
   while(DateTime.UtcNow<until){Find(link,true);list=FileList(main);if(list!=IntPtr.Zero)break;Thread.Sleep(80);}
   if(list==IntPtr.Zero)throw new Fault(409,"AUTO_FILE_DIALOG_NOT_FOUND");
   Choose(list,link.Macro);
   until=DateTime.UtcNow.AddSeconds(12);
   while(DateTime.UtcNow<until){if(completed()){Thread.Sleep(250);return;}Thread.Sleep(80);}
   throw new Fault(409,"AUTO_RESULT_UNKNOWN_NEW_DXF_REQUIRED");
  }finally{
   uint currentPid;GetWindowThreadProcessId(GetForegroundWindow(),out currentPid);
   if(currentPid==(uint)main.pid&&previous!=IntPtr.Zero)SetForegroundWindow(previous);
  }
 }
}
