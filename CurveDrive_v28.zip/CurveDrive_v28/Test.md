# v2.8 test results

- C#5/.NET Framework互換コンパイル成功（Mono6.12、警告をエラー扱い）。
- 元HTMLの構文・計算・復元・出力・送信: 56/56合格。
- 実行EXEのHTTP・状態保存・排他・自動準備/停止条件: 26/26合格。
- BAT/CMD静的検査: 9/9合格。
- Chromium + Monoの手動連携互換試験: 11/11チェック合格。
- 自動連携の座標・紙面/縮尺・前点/基準の照合: 15/15合格。

合計117件/チェック合格。Windows UIを実行した検査ではない。
別のQA用模擬CADでは、初期登録→ON→新点受信→自動引渡し→再実行拒否と、
直前点がない場合の停止・pending保持を確認。模擬UIの差替えコードは配布版に含めない。

## 主な回帰検査

縮尺1/1、1/100、1/1000の用紙座標から、同じ実寸mmへ変換。
別図面、用紙変更、軸角非ゼロ、グループ0以外、計画の基準位置変更、前点消失、
不正数値/ヘッダーで停止。自動引渡し失敗を受信失敗や描画成功と誤表示しない。
既存の左右ズレ、10.5/40m、DXF、JSON/CSV保全、二重引渡し防止を維持。

## 開発者用

C#はBridge.cs AutoBridge.cs CadContext.cs CadNative.csを一緒にビルドし、
System.Web.Extensionsを参照する。

node --test tests/frontend.cjs
python3 tests/bridge.py --exe Bridge.exe --mono /path/to/mono -v
python3 tests/batch.py
node tests/browser.cjs

自動座標検査は同じC#ソースにtests/AutoTests.csを加え、エントリポイントAutoTestsを指定。
ブラウザ試験はPlaywright、CURVE_MONO_PATH、CURVE_CHROMIUM_PATHの指定が必要。
固定ポートを使う試験は直列実行。一時コピーだけを使う。
現場PCの通常利用にNode/Python/Monoは不要。Open.cmdが.NET Frameworkで再ビルドする。

## 実機で残る確認

- Windows側の自動メニュー/ファイル選択が対象Jw_cadで動くこと。
- #hp/#bzの登録と#h4による前点・計画基準の読み取り。
- 登録した発進点で毎回の点指定なしにb0/mmの正しい位置へ追記できること。
- 入力後にHTMLへ操作を戻せること、別のCAD操作中/ダイアログ/中断で停止すること。
- 複数点・左右偏差・ズーム/パン・停止/復旧・重複拒否。

初回はテスト図面一つで行う。実機で未確認の自動操作を動作確認済みとは扱わない。
