using System;
using System.IO;
using System.Text;
using System.Diagnostics;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using System.Text.RegularExpressions;
using Accessibility;

// Reads accessibility metadata only. No CAD commands, input, selection or actions.
class Check {
 delegate bool Callback(IntPtr h,IntPtr p);
 [DllImport("user32.dll")]static extern bool EnumWindows(Callback callback,IntPtr p);
 [DllImport("user32.dll")]static extern uint GetWindowThreadProcessId(IntPtr h,out uint pid);
 [DllImport("user32.dll")]static extern bool IsWindowVisible(IntPtr h);
 [DllImport("user32.dll")]static extern IntPtr GetDlgItem(IntPtr h,int id);
 [DllImport("user32.dll",CharSet=CharSet.Unicode)]static extern int GetClassName(IntPtr h,StringBuilder s,int n);
 [DllImport("oleacc.dll",EntryPoint="AccessibleObjectFromWindow")]static extern int Legacy(IntPtr h,uint objectId,ref Guid iid,[MarshalAs(UnmanagedType.Interface)]out CadAccessible accessible);
 [DllImport("oleacc.dll",EntryPoint="AccessibleObjectFromWindow")]static extern int Standard(IntPtr h,uint objectId,ref Guid iid,[MarshalAs(UnmanagedType.Interface)]out IAccessible accessible);
 static StringBuilder report;
 static int failures;
 static void Row(string s){report.AppendLine(s);}
 static string Error(Exception e){return e.GetType().FullName+" HRESULT=0x"+e.HResult.ToString("X8");}
 static void Read(string label,Func<string> read){try{Row(label+" OK "+read());}catch(Exception e){failures++;Row(label+" ERROR "+Error(e));}}
 static string Class(IntPtr h){var s=new StringBuilder(256);GetClassName(h,s,s.Capacity);return s.ToString();}
 static bool AutoName(string value){return Regex.IsMatch(value??"",@"^Auto_[0-9a-f]{12}(\.bat)?$",RegexOptions.IgnoreCase|RegexOptions.CultureInvariant);}
 static string Item(string name){if(AutoName(name))return "session-macro";if(String.Equals(name,"Setup_Link.bat",StringComparison.OrdinalIgnoreCase)||String.Equals(name,"Setup_Link",StringComparison.OrdinalIgnoreCase))return "setup-macro";return String.IsNullOrEmpty(name)?"empty":"other-name-omitted";}
 static void StandardReads(IAccessible a){
  int count=a.accChildCount;Row("STANDARD.Count OK "+count);
  if(count<0||count>2000){Row("STANDARD.Count outside diagnostic limit");return;}
  int matches=0;
  for(int i=1;i<=count;i++){
   int child=i;string name=null;
   try{name=a.get_accName(child);}catch(Exception e){failures++;Row("STANDARD.Name child="+child+" ERROR "+Error(e));}
   if(AutoName(name))matches++;
   if(i<=8||AutoName(name)||Item(name)=="setup-macro"){
    Row("STANDARD.Item child="+child+" kind="+Item(name));
    Read("STANDARD.Role child="+child,delegate(){object role=a.get_accRole(child);return role is int?((int)role).ToString():"non-integer";});
    Read("STANDARD.State child="+child,delegate(){object state=a.get_accState(child);return state is int?((int)state).ToString():"non-integer";});
    Read("STANDARD.DefaultAction child="+child,delegate(){string action=a.get_accDefaultAction(child);return String.IsNullOrEmpty(action)?"empty":"available";});
   }
  }
  Row("STANDARD.SessionMacroMatches "+matches);
 }
 static void Inspect(IntPtr list){
  Guid iid=typeof(IAccessible).GUID;IAccessible standard=null;CadAccessible legacy=null;
  try{
   int hr=Standard(list,unchecked((uint)-4),ref iid,out standard);Row("STANDARD.Object HRESULT=0x"+hr.ToString("X8"));
   if(hr==0&&standard!=null)Read("STANDARD.Read",delegate(){StandardReads(standard);return "complete";});
  }catch(Exception e){failures++;Row("STANDARD.Object ERROR "+Error(e));}
  try{
   int hr=Legacy(list,unchecked((uint)-4),ref iid,out legacy);Row("LEGACY.Object HRESULT=0x"+hr.ToString("X8"));
   if(hr==0&&legacy!=null){
    Read("LEGACY.Count",delegate(){return legacy.Count().ToString();});
    Read("LEGACY.Name child=1",delegate(){return Item(legacy.Name(1));});
    Read("LEGACY.Role child=1",delegate(){object role=legacy.Role(1);return role is int?((int)role).ToString():"non-integer";});
    Read("LEGACY.DefaultAction child=1",delegate(){return String.IsNullOrEmpty(legacy.DefaultAction(1))?"empty":"available";});
   }
  }catch(Exception e){failures++;Row("LEGACY.Object ERROR "+Error(e));}
  finally{
   if(legacy!=null&&Marshal.IsComObject(legacy))Marshal.ReleaseComObject(legacy);
   if(standard!=null&&Marshal.IsComObject(standard))Marshal.ReleaseComObject(standard);
  }
 }
 static int SelfTest(){
  if(!AutoName("Auto_0123456789ab.bat")||!AutoName("Auto_ABCDEF012345")||AutoName("Other.bat")||AutoName("C:\\Auto_0123456789ab.bat")||AutoName("Auto_0123456789ab.bat.extra"))return 1;
  if(Item("Private.dxf")!="other-name-omitted"||Item("Setup_Link.bat")!="setup-macro")return 1;
  var type=typeof(Check);foreach(var method in type.GetMethods(System.Reflection.BindingFlags.NonPublic|System.Reflection.BindingFlags.Static)){
   var dll=(DllImportAttribute)Attribute.GetCustomAttribute(method,typeof(DllImportAttribute));
   if(dll!=null&&(method.Name.Contains("Send")||method.Name.Contains("Post")||method.Name.Contains("Set")||method.Name.Contains("Write")))return 1;
  }
  Console.WriteLine("PASS redaction/classification and read-only API allowlist. Windows APIs not executed.");return 0;
 }
 [STAThread]static int Main(string[] args){
  if(args.Length==1&&args[0]=="--self-test")return SelfTest();
  if(args.Length!=0)return 2;
  if(Environment.OSVersion.Platform!=PlatformID.Win32NT){Console.WriteLine("Run on Windows with Jw_cad.");return 2;}
  Console.OutputEncoding=Encoding.UTF8;
  Console.WriteLine("JW_CADの外部変形のファイル一覧を開いたままにしてください。");
  Console.WriteLine("一覧が閉じていれば、JW_CADの「その他→外部変形」で開き、BATは選ばないでください。");
  Console.WriteLine("この黒い画面へ戻り、Enterを押してください。図面や選択は変更しません。");Console.ReadLine();
  report=new StringBuilder("CadCheck 1.0 / private read-only accessibility diagnostic\r\nNames, paths and editable values are omitted. No selection/action/input is performed.\r\n");
  Row("ProcessBits "+(IntPtr.Size*8));
  var targets=new HashSet<uint>();
  foreach(var p in Process.GetProcesses()){try{if(String.Equals(p.ProcessName,"Jw_win",StringComparison.OrdinalIgnoreCase))targets.Add((uint)p.Id);}catch(Exception e){Row("PROCESS ERROR "+Error(e));}finally{p.Dispose();}}
  Row("CAD.ProcessCount "+targets.Count);int lists=0;
  EnumWindows(delegate(IntPtr h,IntPtr ignored){
   uint pid;GetWindowThreadProcessId(h,out pid);if(!targets.Contains(pid)||!IsWindowVisible(h))return true;
   IntPtr list=GetDlgItem(h,1882);if(list==IntPtr.Zero||!IsWindowVisible(list)||Class(list)!="SysListView32")return true;
   lists++;Row("LIST "+lists+" class=SysListView32 visible=True");Inspect(list);return true;
  },IntPtr.Zero);
  Row("LIST.Count "+lists);Row("ReadFailures "+failures);
  try{File.WriteAllText(Path.Combine(AppDomain.CurrentDomain.BaseDirectory,"Check.txt"),report.ToString(),new UTF8Encoding(false));}
  catch(Exception e){Console.WriteLine("保存できません: "+Error(e));return 1;}
  Console.WriteLine("読み取り完了。このフォルダーの Check.txt をチャットへ添付してください。");
  if(lists==0)Console.WriteLine("ファイル一覧が見つかりませんでした。Check.txtはそのまま送ってください。");
  return 0;
 }
}
