@echo off
setlocal EnableExtensions DisableDelayedExpansion
cd /d "%~dp0"
title CadCheck - read only
set "CSC=%SystemRoot%\Microsoft.NET\Framework64\v4.0.30319\csc.exe"
if not exist "%CSC%" set "CSC=%SystemRoot%\Microsoft.NET\Framework\v4.0.30319\csc.exe"
set "ACC=%SystemRoot%\Microsoft.NET\Framework\v4.0.30319\Accessibility.dll"
if not exist "%ACC%" set "ACC=%SystemRoot%\Microsoft.NET\assembly\GAC_MSIL\Accessibility\v4.0_4.0.0.0__b03f5f7f11d50a3a\Accessibility.dll"
if not exist "%CSC%" goto failed
if not exist "%ACC%" goto failed
"%CSC%" /nologo /codepage:65001 /langversion:5 /target:exe /out:"%~dp0Check.exe" /reference:"%ACC%" "%~dp0Check.cs" "%~dp0Legacy.cs"
if errorlevel 1 goto failed
"%~dp0Check.exe"
pause
exit /b 0
:failed
echo Cannot compile CadCheck. Keep the error message above.
pause
exit /b 1
