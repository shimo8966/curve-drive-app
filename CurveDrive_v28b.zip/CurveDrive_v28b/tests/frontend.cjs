'use strict';
// Runs the delivered HTML's actual inline JavaScript. Minimal DOM/network mocks;
// this suite does not launch Windows or JW_CAD and does not establish CAD placement.
const fs=require('node:fs'),path=require('node:path'),vm=require('node:vm');
const assert=require('node:assert/strict'),{test}=require('node:test');
const html=fs.readFileSync(path.join(__dirname,'../app.html'),'utf8');
const scripts=[...html.matchAll(/<script\b[^>]*>([\s\S]*?)<\/script>/g)];
const startup='segRender();measRender();preview();if(recoveryNotice)';
assert.equal(scripts[1][1].split(startup).length,2,'Update the test adapter after intentional startup changes.');
const injected=scripts[1][1].replace(startup,`globalThis.app={model,advance,pointAt,samplePlan,dxf,parseCSV,snapshot,validateData,applyData,refresh,preview,planKey,fileName,bridgeSend,bridgeBaseline,bridgeCheck,bridgeRequest,autoAction};${startup}`);
function load(options={}){
 const nodes=new Map(),storage=new Map(Object.entries(options.storage||{})),requests=[],alerts=[],confirms=[],timers=[],downloads=[];
 let env;
 function element(id){if(!nodes.has(id)){
  const attrs=html.match(new RegExp('<input\\b[^>]*id="'+id+'"[^>]*>'))?.[0]||'';
  nodes.set(id,{value:attrs.match(/value="([^"]*)"/)?.[1]||'',style:{},disabled:false,innerHTML:'',textContent:'',className:'',listeners:{},
   addEventListener(k,fn){(this.listeners[k]??=[]).push(fn)},querySelector(){return{focus(){},scrollIntoView(){}}},click(){return this.onclick?.()}});
 }return nodes.get(id)}
 const context=vm.createContext({document:{getElementById:element,createElement:()=>({click(){downloads.push({name:this.download,href:this.href})}})},window:{addEventListener(){}},
  localStorage:{getItem:k=>storage.get(k)??null,setItem:(k,v)=>{if(options.storageFail)throw Error('quota');storage.set(k,v)}},
  location:{origin:'http://127.0.0.1:18718',href:'http://127.0.0.1:18718/'},
  setTimeout:(fn,ms)=>{const t={fn,ms,active:true};timers.push(t);return t},clearTimeout:t=>{if(t)t.active=false},
  confirm:message=>{confirms.push(message);return options.confirm!==false},alert:message=>alerts.push(message),
  fetch:async(url,opts)=>{const body=opts.body?JSON.parse(opts.body):undefined;const req={url,body,opts};requests.push(req);
   if(options.fetch)return options.fetch(req,env);
   let result=url.endsWith('health')?{ok:true,version:'2.8b'}:url.endsWith('latest')?env.latest:{ok:true,saved:'test'};
   return{ok:true,status:200,json:async()=>result};},
  AbortController,Blob,URL,TextDecoder,console});
 new vm.Script(scripts[0][1]).runInContext(context);new vm.Script(injected).runInContext(context);
 env={app:context.app,element,storage,requests,alerts,confirms,timers,downloads};
 env.latest={ok:true,hasBaseline:true,state:'ready',site:'サンプル現場',planKey:env.app.planKey(),session:'session-test',station:10,saved:'test',hasPoint:false};
 return env;
}
function clone(v){return JSON.parse(JSON.stringify(v))}
function close(a,b,t=1e-9){assert.ok(Math.abs(a-b)<=t,`${a} != ${b}`)}
function base(e){return JSON.stringify(e.app.snapshot())}
async function importJSON(e,obj){await e.element('jsonFile').onchange({target:{files:[{text:async()=>typeof obj==='string'?obj:JSON.stringify(obj)}],value:'sample'}})}
async function importCSV(e,text){await e.element('csvFile').onchange({target:{files:[{arrayBuffer:async()=>new TextEncoder().encode(text).buffer}],value:'sample'}})}
function keyEvent(e,stationRow=2,extra={}){
 const event={key:'Enter',ctrlKey:false,altKey:false,metaKey:false,isComposing:false,repeat:false,shiftKey:false,
  target:{dataset:{meas:String(stationRow),key:'up'},matches:()=>true},preventDefault(){this.prevented=true},...extra};
 return Promise.all(e.element('measBody').listeners.keydown.map(fn=>fn(event)));
}
function post(e,route){return e.requests.filter(r=>r.url.endsWith(route)&&r.body)}
function setMeasurements(e,mm){const d=clone(e.app.snapshot());d.meas=mm;e.app.applyData(e.app.validateData(d))}
function parseEntities(dxf){const lines=dxf.trim().split(/\r?\n/);let current,out=[];for(let i=0;i<lines.length;i+=2){const c=lines[i].trim(),v=lines[i+1];if(c==='0'){current={type:v};out.push(current)}else if(current)current[c]=v}return out}
test('both delivered inline scripts parse',()=>{assert.equal(scripts.length,2);for(const s of scripts)new vm.Script(s[1])});
test('delivered UI says v2.8b and has no obsolete macro instruction',()=>{assert.match(html,/<title>[^<]*v2\.8/);assert.doesNotMatch(html,/v2\.4|01_AppendPoint_v13|Start_Bridge_NoPS|旧方式|Excel/)});
test('default geometry 10.5m and translated origin remain accurate',()=>{
 const e=load(),p=e.app.model().mm.find(p=>p.s===10.5);close(p.x,10.49990791704427);close(p.y,.019249772396300064);
 e.element('x0').value='123';e.element('y0').value='-456';const q=e.app.model().mm.find(p=>p.s===10.5);close(q.x,123+p.x);close(q.y,-456+p.y);
});
test('left and right R100 quarter circles preserve signs',()=>{const e=load(),a=e.app.advance(0,0,0,Math.PI*50,.01),b=e.app.advance(0,0,0,Math.PI*50,-.01);close(a.x,100);close(a.y,100);close(b.x,100);close(b.y,-100)});
test('default plan station40 matches independent circle-centre reference',()=>{
 const e=load();setMeasurements(e,[{s:'40',left:'20',up:''}]);const p=e.app.model().mm[0];
 close(p.x,39.81103785498893);close(p.y,3.0804728375231347);
 const points=parseEntities(e.app.dxf(e.app.model())).filter(q=>q.type==='CIRCLE'&&q[8]==='MEAS_PT');
 assert.equal(points.length,1);close(+points[0][10],p.x*1000,5.01e-8);close(+points[0][20],p.y*1000,5.01e-8);
});
test('DXF measured coordinates and red/green layers remain',()=>{const e=load(),m=e.app.model(),text=e.app.dxf(m),entities=parseEntities(text);const points=entities.filter(q=>q.type==='CIRCLE'&&q[8]==='MEAS_PT');assert.equal(points.length,3);close(+points[2][10],m.mm[2].x*1000,5.01e-8);close(+points[2][20],m.mm[2].y*1000,5.01e-8);assert.match(text,/PLAN\r\n 70\r\n0\r\n 62\r\n1/);assert.match(text,/MEAS_PT\r\n 70\r\n0\r\n 62\r\n3/)});
test('large plan is rejected before allocating its 200001 samples',()=>{const e=load(),d=clone(e.app.snapshot());d.segs=[{type:'S',l:'10000',r:''}];d.meas=[];d.basics.pitch='.05';e.app.applyData(e.app.validateData(d));assert.throws(()=>e.app.samplePlan(e.app.model()),/20000/);e.app.preview();assert.match(e.element('status').textContent,/20000/);assert.doesNotMatch(e.element('status').textContent,/stack/)});
test('sample budget counts each segment and origin',()=>{const e=load(),m=e.app.model();m.ss=[{l:10000}];m.pitch=.5;assert.throws(()=>e.app.samplePlan(m),/20000/)});
test('ASCII filenames stay short and independent from raw site identity',()=>{const e=load();e.element('site').value='日本語 現場/../../名';assert.match(e.app.fileName(),/^[A-Za-z0-9_]{1,40}$/);assert.ok(e.app.fileName().length<=40)});
test('plan key excludes pitch and measurements, normalizes numeric strings',()=>{const e=load(),key=e.app.planKey();e.element('pitch').value='1';const d=clone(e.app.snapshot());d.basics.x0='0.0';d.segs[0].l=10;d.meas=[];e.app.applyData(e.app.validateData(d));assert.equal(e.app.planKey(),key);e.element('grade').value='1';assert.notEqual(e.app.planKey(),key)});
for(const [name,mutate] of [
 ['null segment',d=>d.segs[0]=null],['unknown segment type',d=>d.segs[0].type='BAD'],['object measurement',d=>d.meas[0].left={}],['nonfinite number',d=>d.basics.x0='Infinity'],['duplicate station',d=>d.meas.push({...d.meas[0]})],['missing basics',d=>delete d.basics]
])test('JSON transaction rejects '+name+' without changing active/saved data',async()=>{const e=load();e.app.refresh();const before=base(e),saved=e.storage.get('curve-drive-v28'),d=clone(e.app.snapshot());mutate(d);await importJSON(e,d);assert.equal(base(e),before);assert.equal(e.storage.get('curve-drive-v28'),saved);assert.equal(e.alerts.length,1)});
test('valid JSON restoration commits and persists only the checked candidate',async()=>{const e=load(),d=clone(e.app.snapshot());d.basics.site=' restored ';d.meas=[{s:1,left:2,up:''}];await importJSON(e,d);assert.equal(e.alerts.length,0);assert.equal(e.app.snapshot().meas[0].s,'1');assert.equal(JSON.parse(e.storage.get('curve-drive-v28')).basics.site,' restored ')});
for(const text of ['10,abc,0','10,"18\n10.5,20,0','bad,2,0','10,2,0,extra'])test('CSV transaction preserves data for '+JSON.stringify(text),async()=>{const e=load();e.app.refresh();const before=base(e),saved=e.storage.get('curve-drive-v28');await importCSV(e,text);assert.equal(base(e),before);assert.equal(e.storage.get('curve-drive-v28'),saved);assert.equal(e.alerts.length,1)});
test('CSV normal quoting and optional vertical values parse',async()=>{const e=load();assert.equal(JSON.stringify(e.app.parseCSV('"a,b","a""b"\r\n"c\nd",e\r\n')),JSON.stringify([['a,b','a"b'],['c\nd','e']]));await importCSV(e,'推進延長_m,左右ズレ_mm_左正,上下ズレ_mm_上正\r\n1,2,\r\n2,3,4');assert.equal(e.alerts.length,0);assert.equal(e.app.model().mm[0].up,null)});
test('corrupt saved state is preserved and cannot break startup',()=>{const e=load({storage:{'curve-drive-v28':'{"segs":[null]}'}});assert.equal(e.app.model().mm.length,3);assert.match(e.element('saveStatus').textContent,/不正/);assert.equal(e.storage.get('curve-drive-v28'),'{"segs":[null]}')});
test('valid old storage recovers after corrupt new state',()=>{const data=clone(load().app.snapshot());data.basics.site='OldSite';const e=load({storage:{'curve-drive-v28':'bad','curve-drive-v03':JSON.stringify(data)}});assert.equal(e.element('site').value,'OldSite');assert.match(e.element('saveStatus').textContent,/以前の有効/)});
test('storage failure is visible',()=>{const e=load({storageFail:true});e.app.refresh();assert.match(e.element('saveStatus').textContent,/保存未完了/)});
test('baseline requires explicit confirmation; cancel sends nothing',async()=>{const e=load({confirm:false});assert.equal(await e.app.bridgeBaseline(),false);assert.equal(e.requests.length,0);assert.match(e.confirms[0],/テスト用コピー/);assert.match(e.confirms[0],/既知測点/)});
test('one-point baseline uses raw site, plan key and relative coordinate',async()=>{const e=load();setMeasurements(e,[{s:'5',left:'15',up:''}]);e.element('site').value=' 日本語現場 ';e.element('x0').value='123';e.element('y0').value='456';assert.equal(await e.app.bridgeBaseline(),true);const body=post(e,'baseline')[0].body;assert.equal(body.site,'日本語現場');assert.equal(body.station,5);close(body.p.x,5);close(body.p.y,.015);assert.equal(body.planKey,e.app.planKey())});
test('sending newest point uses registered session and previous endpoint',async()=>{const e=load();assert.equal(await e.app.bridgeSend(),true);const body=post(e,'point')[0].body;assert.equal(body.session,'session-test');assert.equal(body.station,10.5);assert.equal(body.previousStation,10);assert.equal(body.site,'サンプル現場');assert.equal(body.offsetMm,18);close(body.p.x,10.49990791704427);assert.match(e.element('bridgeStatus').textContent,/描画は未確認/)});
test('Enter on historical row does not silently send newest point',async()=>{const e=load(),before=base(e);await keyEvent(e,0);assert.equal(e.requests.length,0);assert.equal(base(e),before);assert.match(e.element('bridgeStatus').textContent,/最新の測点だけ/)});
for(const extra of [{ctrlKey:true},{altKey:true},{metaKey:true},{isComposing:true},{repeat:true}])test('Enter guard '+JSON.stringify(extra),async()=>{const e=load(),before=base(e);await keyEvent(e,2,extra);assert.equal(e.requests.length,0);assert.equal(base(e),before)});
test('Enter on latest row sends once then adds one blank row',async()=>{const e=load();await keyEvent(e);assert.equal(post(e,'point').length,1);assert.equal(e.app.snapshot().meas.length,4);assert.equal(e.app.snapshot().meas[3].s,'')});
test('Tab appends input only and does not send',async()=>{const e=load();await keyEvent(e,2,{key:'Tab'});assert.equal(e.requests.length,0);assert.equal(e.app.snapshot().meas.length,4)});
test('one-point send asks for a point after baseline without posting',async()=>{const e=load();setMeasurements(e,[{s:'5',left:'15',up:''}]);e.latest.station=5;assert.equal(await e.app.bridgeSend(),false);assert.equal(post(e,'point').length,0);assert.match(e.element('bridgeStatus').textContent,/新しい測点/)});
test('busy guard prevents concurrent sends and baseline resets',async()=>{let release;const e=load({fetch:async(req,env)=>{if(req.url.endsWith('latest'))await new Promise(r=>release=r);return{ok:true,status:200,json:async()=>req.url.endsWith('latest')?env.latest:{ok:true}}}});const first=e.app.bridgeSend();assert.equal(await e.app.bridgeSend(),false);assert.equal(await e.app.bridgeBaseline(),false);assert.equal(e.requests.length,1);release();assert.equal(await first,true);assert.equal(post(e,'point').length,1);assert.equal(e.element('bridgeSend').disabled,false)});
test('identical pending point may be resent for server idempotency check',async()=>{const e=load();e.latest.state='pending';e.latest.station=10.5;assert.equal(await e.app.bridgeSend(),true);assert.equal(post(e,'point').length,1)});
test('pending point cannot be overwritten by a newer measurement',async()=>{const e=load();e.latest.state='pending';e.latest.station=10;assert.equal(await e.app.bridgeSend(),false);assert.equal(post(e,'point').length,0);assert.match(e.element('bridgeStatus').textContent,/未引渡し/)});
test('issued point cannot be sent again',async()=>{const e=load();e.latest.state='issued';e.latest.station=10.5;assert.equal(await e.app.bridgeSend(),false);assert.equal(post(e,'point').length,0)});
test('site and plan mismatch reject before POST',async()=>{for(const change of [e=>e.latest.site='Other',e=>e.latest.planKey='Other']){const e=load();change(e);assert.equal(await e.app.bridgeSend(),false);assert.equal(post(e,'point').length,0)}});
test('skipping an unsubmitted previous endpoint is rejected',async()=>{const e=load();e.latest.station=5;assert.equal(await e.app.bridgeSend(),false);assert.equal(post(e,'point').length,0);assert.match(e.element('bridgeStatus').textContent,/未送信/)});
test('POST network failure reports unknown acceptance, not definitely unsent',async()=>{const e=load({fetch:async(req,env)=>{if(req.body)throw Error('lost reply');return{ok:true,status:200,json:async()=>env.latest}}});assert.equal(await e.app.bridgeSend(),false);assert.match(e.element('bridgeStatus').textContent,/受信結果が不明/);assert.equal(e.element('bridgeSend').disabled,false)});
test('timeout aborts POST and carries uncertain result',async()=>{const e=load({fetch:async(req)=>new Promise((resolve,reject)=>req.opts.signal.addEventListener('abort',()=>reject(Object.assign(Error('aborted'),{name:'AbortError'}))))});const request=e.app.bridgeRequest('point',{station:1});const timer=e.timers.find(t=>t.ms===8000&&t.active);timer.fn();await assert.rejects(request,err=>err.uncertain===true&&/時間内/.test(err.message));assert.equal(timer.active,false)});
test('server 409 is a known refusal and restores controls',async()=>{const e=load({fetch:async(req,env)=>req.body?{ok:false,status:409,json:async()=>({error:'ALREADY_ISSUED'})}:{ok:true,status:200,json:async()=>env.latest}});assert.equal(await e.app.bridgeSend(),false);assert.match(e.element('bridgeStatus').textContent,/409/);assert.doesNotMatch(e.element('bridgeStatus').textContent,/受信結果が不明/);assert.equal(e.element('bridgeSend').disabled,false)});
test('issued status means handed off, CAD result remains unverified',async()=>{const e=load();e.latest.state='issued';await e.app.bridgeCheck();assert.match(e.element('bridgeStatus').textContent,/一回引渡し済み/);assert.match(e.element('bridgeStatus').textContent,/描画結果は未確認/)});

for(const [button,suffix]of [['exportJson','_Data.json'],['exportCsv','_Meas.csv']]){
 test(button+' rejects incomplete rows before creating an unrestorable download',()=>{const e=load();e.app.snapshot().meas.push({s:'11',left:'',up:''});e.element(button).onclick();assert.equal(e.downloads.length,0);assert.equal(e.element('status').className,'error');assert.match(e.element('status').textContent,/未完成の行を完成するか削除/)});
 test(button+' downloads checked valid data with ASCII filename',()=>{const e=load();e.element(button).onclick();assert.equal(e.downloads.length,1);assert.match(e.downloads[0].name,/^[A-Za-z0-9_]+\.(json|csv)$/);assert.ok(e.downloads[0].name.endsWith(suffix));assert.equal(e.element('status').className,'ok')});
}

test('CAD output converts straight50m to50000mm, offset20mm remains20mm',()=>{const e=load(),d=clone(e.app.snapshot());d.segs=[{type:'S',l:'50',r:''}];d.meas=[{s:'10.5',left:'20',up:'20'}];e.app.applyData(e.app.validateData(d));const entities=parseEntities(e.app.dxf(e.app.model()));const plan=entities.filter(q=>q.type==='LINE'&&q[8]==='PLAN');close(+plan.at(-1)[11],50000);const point=entities.find(q=>q.type==='CIRCLE'&&q[8]==='MEAS_PT');close(+point[10],10500);close(+point[20],20);close(+point[40],35);const profile=entities.filter(q=>q.type==='LINE'&&q[8]==='PROFILE');close(+profile.at(-1)[11],50000);const up=entities.find(q=>q.type==='CIRCLE'&&q[8]==='MEAS_Z');close(+up[20],-29980)});
test('v2.5 valid saved inputs migrate without scaling field measurements',()=>{const data=clone(load().app.snapshot());data.basics.site='Previous';const e=load({storage:{'curve-drive-v25':JSON.stringify(data)}});assert.equal(e.element('site').value,'Previous');close(e.app.model().mm[2].s,10.5);close(e.app.model().mm[2].left,18)});
test('v2.6 inputs including an11m test point migrate as measurements, not CAD state',()=>{const data=clone(load().app.snapshot());data.meas.push({s:'11',left:'20',up:''});const e=load({storage:{'curve-drive-v26':JSON.stringify(data)}});close(e.app.model().mm.at(-1).s,11);close(e.app.model().mm.at(-1).left,20);assert.match(e.app.planKey(),/mm-real-v28-auto/)});

test('enabled automatic link posts the point then invokes guarded CAD handoff',async()=>{const e=load();e.latest.automation={prepared:true,calibrated:true,enabled:true};assert.equal(await e.app.bridgeSend(),true);assert.equal(post(e,'point').length,1);assert.equal(post(e,'auto/apply').length,1);assert.equal(post(e,'auto/apply')[0].body.session,'session-test');assert.match(e.element('bridgeStatus').textContent,/自動引渡ししました/)});
test('automatic handoff refusal preserves accepted-input status and does not claim drawing success',async()=>{const e=load({fetch:async(req,env)=>{if(req.url.endsWith('auto/apply'))return{ok:false,status:409,json:async()=>({ok:false,error:'CAD_PLAN_ANCHORS_CHANGED'})};return{ok:true,status:200,json:async()=>req.url.endsWith('latest')?env.latest:{ok:true}}}});e.latest.automation={prepared:true,enabled:true};assert.equal(await e.app.bridgeSend(),false);assert.equal(post(e,'point').length,1);assert.match(e.element('bridgeStatus').textContent,/PC受信後に自動連携を停止/);assert.doesNotMatch(e.element('bridgeStatus').textContent,/自動引渡ししました/)});
test('pending automatic failure does not instruct a manual import on status check',async()=>{const e=load();e.latest.state='pending';e.latest.automation={prepared:true,enabled:false,message:'AUTO_ITEM_ACTION_FAILED_CHECK_STATUS'};await e.app.bridgeCheck();assert.match(e.element('bridgeStatus').textContent,/未引渡し/);assert.match(e.element('bridgeStatus').textContent,/再送や手動取り込みはせず/);assert.doesNotMatch(e.element('bridgeStatus').textContent,/Curve_Latest/)});
test('pending point received with prepared disabled link does not suggest manual execution',async()=>{const e=load();e.latest.automation={prepared:true,enabled:false};assert.equal(await e.app.bridgeSend(),true);assert.equal(post(e,'point').length,1);assert.equal(post(e,'auto/apply').length,0);assert.match(e.element('bridgeStatus').textContent,/再送・手動取り込みをせず/);assert.doesNotMatch(e.element('bridgeStatus').textContent,/Curve_Latest/)});
