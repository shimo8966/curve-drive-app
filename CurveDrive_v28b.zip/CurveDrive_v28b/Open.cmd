@echo off
setlocal EnableExtensions DisableDelayedExpansion
cd /d "%~dp0"
start "CurveDrive v2.8b" "%ComSpec%" /d /c ""%~dp0Start.cmd""
exit /b 0
