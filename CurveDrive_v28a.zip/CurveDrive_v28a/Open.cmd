@echo off
setlocal EnableExtensions DisableDelayedExpansion
cd /d "%~dp0"
start "CurveDrive v2.8a" "%ComSpec%" /d /c ""%~dp0Start.cmd""
exit /b 0
