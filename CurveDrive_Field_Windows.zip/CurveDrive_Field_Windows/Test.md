Windows実Edgeによる検証：GitHub Actions run 44134481012 / commit cc1df4bb5c8c1e3b34d66a22ff00bb155940863a

PASS Legacy PC data is copied without modifying original files
PASS Plan-only app starts without JW and without latest-point button
PASS Plan-only backup contains no fabricated actual measurement
PASS PC automatically saves unfinished measurement rows as well as complete values
PASS Closing the app retains the latest typed value in a PC file
PASS New app process, new port and fresh browser context restore latest PC data without browser storage
PASS Clicking the actual plan point shows station, line type and signed deviations
PASS Deviation graph selection identifies the selected measurement, rather than the latest point
PASS Measurement selection supports keyboard Enter
PASS Plan zoom and whole-plan reset work
PASS Automatic previous PC backup is present and readable
PASS Narrow-screen measurement cards fit a phone-width viewport
PASS Plan colors and explicit curve station ranges distinguish all three segment types
PASS Exact-boundary measured point reports the segment transition
PASS New project is truly blank and previous plan/actuals remain in saved list
PASS Renaming changes the current project, without creating or deleting a project
PASS Switching back restores plan, measurements and shared palette
PASS Whole-workspace import adds restored copies and retains existing projects
PASS Failed checkpoint keeps the current project visible instead of losing its draft
PASS Restart restores the selected project and the complete project catalogue
PASS Closing while initial saved data is unavailable cannot overwrite PC files with defaults
PASS Web mode restores incomplete drafts without sending project data to any server
PASS Curve selection reports the planned curved segment and radius
PASS Independent IndexedDB copy restores data when primary browser storage is removed
PASS Installed shell and saved web data reopen offline after initial cache is ready
PASS No uncaught JavaScript error or project-data network request in browser-only mode
RESULT 26 Windows app checks passed

追加検証：Nodeによる幾何計算と現場カタログの検証、保存APIのHTTP検証が通過。
Site上の実ブラウザー確認は環境の制約で未実施。同じ静的資産を配布。
