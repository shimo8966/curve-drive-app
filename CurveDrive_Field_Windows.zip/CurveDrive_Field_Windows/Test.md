Windows実Edge検証：run 44511396492 / commit 9c41803b71263cce455519056ad0b6ea602a5c9b

PASS L curve-to-straight continuation: predicted 44.418mm, analytic 44.437mm
PASS R curve-to-straight continuation: predicted -44.418mm, analytic -44.437mm
PASS linear trend, normal-offset curve, sparse/short/unstable suppression, dense/irregular spacing, plan-end clipping, large-coordinate invariance and immutable measured data
PASS Legacy PC data is copied without modifying original files
PASS Plan-only app starts without JW and without latest-point button
PASS Plan-only backup contains no fabricated actual measurement
PASS PC automatically saves unfinished measurement rows as well as complete values
PASS Closing the app retains the latest typed value in a PC file
PASS New app process, new port and fresh browser context restore latest PC data without browser storage
PASS Clicking the actual plan point shows station, line type and signed deviations
PASS Deviation graph selection identifies the selected measurement, rather than the latest point
PASS Selection synchronizes both graphs in both directions without leaving the previous point highlighted
PASS Editable positive and negative tolerance lines remain visible and save with the current project
PASS Measurement selection supports keyboard Enter
PASS Plan zoom and whole-plan reset work
PASS Mouse wheel zooms both directions around the cursor within one screen pixel without page scrolling
PASS Panning remains available after wheel zoom and whole-plan reset is still explicit
PASS Automatic previous PC backup is present and readable
PASS Narrow-screen measurement cards fit a phone-width viewport
PASS Plan colors and explicit curve station ranges distinguish all three segment types
PASS Exact-boundary measured point reports the segment transition
PASS Curve labels stay outside the plot and actual points remain above all plan and boundary graphics after zoom
PASS Both stacked charts, five alignment bars, editable tolerance and selected-point values fit without page scrolling at six viewport sizes
PASS Mouse dragging enlarges the plan frame and shrinks the deviation frame while preserving data and synchronized selection
PASS Resize limits keep both diagrams visible even when dragged toward the screen edge
PASS Standard reset and keyboard resizing work and persist to the PC save file
PASS Input and management switching preserves synchronized selection and current data
PASS New project is truly blank and previous plan/actuals remain in saved list
PASS Renaming changes the current project, without creating or deleting a project
PASS Switching back restores plan, measurements and shared palette
PASS Whole-workspace import adds restored copies and retains existing projects
PASS Failed checkpoint keeps the current project visible instead of losing its draft
PASS Restart restores the selected project and the complete project catalogue
PASS Frame-size preference survives a new app process and fresh browser storage
PASS Quick-entry partial measurement survives PC save and reload, then resumes at the missing field
PASS Quick entry returns directly to both graphs with the added point selected and saved on PC
PASS Adding the next measurement preserves the existing plan zoom and pan position
PASS Opening and closing an empty quick-entry dialog adds no blank measurement row
PASS Closing while initial saved data is unavailable cannot overwrite PC files with defaults
PASS Web mode restores incomplete drafts without sending project data to any server
PASS Curve selection reports the planned curved segment and radius
PASS Quick entry validates required fields and duplicate stations before returning to the graph
PASS Quick entry rejects out-of-plan stations and accepts blank optional up/depth fields
PASS A new outlying measurement cannot shift the plan projection or existing measurement positions
PASS The plan origin marker remains a readable fixed screen size when zooming
PASS Independent IndexedDB copy restores data when primary browser storage is removed
PASS Installed shell and saved web data reopen offline after initial cache is ready
PASS Reference forecast continues actual curvature beyond the planned curve end and shows predicted normal offsets separately
PASS Forecast samples never become measured rows in saved data or CSV output
PASS Forecast readout, tolerance, alignment bars and both graphs remain visible at phone width
PASS Forecast toggle preserves manual zoom and its per-project preference survives reload
PASS Unstable recent measurements suppress the reference forecast without hiding actual measurements
PASS Insufficient measurement count displays a clear requirement instead of a forecast
PASS No uncaught JavaScript error or project-data network request in browser-only mode
RESULT 51 Windows app checks passed

予測計算は既知の直線傾向・左右円弧・カーブ終了後の継続・一定法線オフセット・座標回転移動・高密度と不等間隔・計画到達点・測点不足とばらつき抑制・実測不変性を検証。
画面では参考線と数値、保存設定、CSV/JSONへ予測点が混ざらないこと、360px幅、拡大表示の維持を確認。
これらは計算・動作検証であり、実現場での予測精度を保証するものではありません。地盤・機械・操作遅れは未モデル化。
Sites上のブラウザー確認は環境制約で未実施。同じ静的資産を配布。
