カーブ推進 現場アプリ 1.1 / Windows版

最初にZIPを「すべて展開」し、CurveDrive.exeをダブルクリックします。distフォルダーは一緒に置いてください。
JW・Open.cmd・黒い連携画面は使いません。WindowsのEdgeで独立したアプリ窓を開きます。

計画だけで開始できます。実測を追加し、グラフの点を押すと始点からの延長・直線/曲線・左右と上下のズレ量を確認できます。
入力途中もPCに自動保存します。閉じた後、再びCurveDrive.exeを開くと最後の入力を読み込みます。
保存場所：ユーザーのLocalAppData\CurveDriveField\Project.json。自動の控えはProject.previous.jsonです。
別の端末へ渡す場合は画面の「現場データをバックアップ」でJSONを保存し、相手のアプリで復元してください。以前のHTML版のJSONも読み込めます。

Web版・LINEで共有するリンク：
https://curve-drive-field-app.welcomingopera8.chatgpt.site/
リンクの共有に入力データは含まれません。端末間の自動同期はありません。
Web版は端末のブラウザー内に自動保存します。
深さは独立した記録用の値で、上下ズレへ自動変換しません。
